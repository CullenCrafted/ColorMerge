import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { HelpCircle, RotateCcw, Pause, Volume2, VolumeX, Trophy, Heart, Zap } from "lucide-react";
import { ColorMergeLogic } from "@/lib/colormerge-logic";
import { useAudio } from "@/hooks/use-audio";
import { useGameStats } from "@/hooks/use-game-stats";
import { useToast } from "@/hooks/use-toast";
import InstructionsModal from "@/components/instructions-modal";
import GameOverModal from "@/components/game-over-modal";
import HeartsOutModal from "@/components/hearts-out-modal";

export default function ColorMerge() {
  const [showInstructions, setShowInstructions] = useState(false);
  const [showGameOver, setShowGameOver] = useState(false);
  const [showHeartsOut, setShowHeartsOut] = useState(false);

  const [gameLogic, setGameLogic] = useState<ColorMergeLogic>(new ColorMergeLogic());
  const [gameState, setGameState] = useState(gameLogic.getState());
  const [isPaused, setIsPaused] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [showSuccessFlash, setShowSuccessFlash] = useState(false);
  const [showHeartLoss, setShowHeartLoss] = useState(false);
  const [showHeartGain, setShowHeartGain] = useState(false);
  const [showCorrectAnswer, setShowCorrectAnswer] = useState(false);
  const [lastGuess, setLastGuess] = useState<string[]>([]);
  const [allIncorrectGuesses, setAllIncorrectGuesses] = useState<Array<{guess: string[], correct: string[], level: number}>>([]);
  const [enhancedHaptics, setEnhancedHaptics] = useState(false);
  const [bubbles, setBubbles] = useState<Array<{id: string, x: number, y: number, size: number, color: string, delay: number, type: 'primary' | 'secondary'}>>([]);
  const [finalLevelReached, setFinalLevelReached] = useState(1);
  const { stats, updateStats } = useGameStats("colormerge");
  const { toast } = useToast();
  const { toggleBackgroundMusic, initializeAudio } = useAudio();

  // Haptic feedback function
  const triggerHaptic = (type: 'light' | 'medium' | 'heavy' = 'light') => {
    if ('vibrate' in navigator) {
      const basePatterns = {
        light: [10],
        medium: [20],
        heavy: [50]
      };
      const enhancedPatterns = {
        light: [15, 5, 15],
        medium: [30, 10, 30],
        heavy: [80, 20, 80, 20, 80]
      };
      const patterns = enhancedHaptics ? enhancedPatterns : basePatterns;
      navigator.vibrate(patterns[type]);
    }
  };

  // Calculate text color based on background brightness
  const getContrastTextColor = (backgroundColor: string): string => {
    // Extract RGB values from rgb() string
    const rgbMatch = backgroundColor.match(/rgb\((\d+),\s*(\d+),\s*(\d+)\)/);
    if (!rgbMatch) return 'text-white';
    
    const [, r, g, b] = rgbMatch.map(Number);
    // Calculate brightness using relative luminance formula
    const brightness = (r * 0.299 + g * 0.587 + b * 0.114);
    
    return brightness > 128 ? 'text-black' : 'text-white';
  };

  useEffect(() => {
    if (stats) {
      const newLogic = new ColorMergeLogic((stats as any).currentLevel || 1, (stats as any).hearts || 3);
      setGameLogic(newLogic);
      setGameState(newLogic.getState());
    }
  }, [stats]);

  // Initialize audio on component mount and start background music
  useEffect(() => {
    initializeAudio();
    if (soundEnabled) {
      toggleBackgroundMusic(true);
    }
  }, [initializeAudio]);

  // Toggle background music when soundEnabled changes
  useEffect(() => {
    toggleBackgroundMusic(soundEnabled);
  }, [soundEnabled, toggleBackgroundMusic]);

  // Trigger haptic feedback when level changes
  useEffect(() => {
    triggerHaptic('medium');
  }, [gameState.currentLevel]);

  const handleColorClick = (color: string) => {
    if (isPaused) return;
    
    triggerHaptic('light');
    const previousHeartCount = gameState.hearts;
    
    // Store the guess before adding the color
    const currentGuess = [...Object.entries(gameState.colorClicks)
      .filter(([_, count]) => count > 0)
      .flatMap(([color, count]) => Array(count).fill(color))];
    currentGuess.push(color);
    setLastGuess(currentGuess);
    
    const result = gameLogic.addColor(color);
    const newState = gameLogic.getState();
    setGameState(newState);

    // Check for heart changes
    if (newState.hearts < previousHeartCount) {
      // Heart lost - store incorrect guess for final summary
      triggerHaptic('heavy');
      setShowHeartLoss(true);
      
      const newIncorrectGuess = {
        guess: currentGuess,
        correct: gameLogic.getCurrentTargetColorArray(),
        level: gameState.currentLevel
      };
      setAllIncorrectGuesses(prev => [...prev, newIncorrectGuess]);
      
      setTimeout(() => {
        setShowHeartLoss(false);
      }, 1500);
    }

    if (result.levelComplete) {
      // SUCCESS - Store the matched color BEFORE any changes
      const exactMatchedColor = gameLogic.getCurrentColorString();
      console.log('EXACT matched background color for bubbles:', exactMatchedColor);
      
      // Success effects first
      triggerHaptic('heavy');
      setShowSuccessFlash(true);
      
      // Store hearts before advancing
      const prevHearts = gameLogic.getState().hearts;
      
      // Create bubbles with the matched color
      const primaryBubbles = Array.from({ length: 12 }, (_, i) => {
        const angle = (i / 12) * 2 * Math.PI + Math.random() * 0.3;
        const distance = 400 + Math.random() * 300;
        return {
          id: `primary-${Date.now()}-${i}`,
          x: Math.cos(angle) * distance,
          y: Math.sin(angle) * distance,
          size: Math.random() * 25 + 30,
          color: exactMatchedColor,
          delay: Math.random() * 100,
          type: 'primary' as const
        };
      });
      
      const secondaryBubbles = Array.from({ length: 24 }, (_, i) => {
        const angle = (i / 24) * 2 * Math.PI + Math.random() * 0.4;
        const distance = 200 + Math.random() * 150;
        return {
          id: `secondary-${Date.now()}-${i}`,
          x: Math.cos(angle) * distance,
          y: Math.sin(angle) * distance,
          size: Math.random() * 15 + 15,
          color: exactMatchedColor,
          delay: 200 + Math.random() * 150,
          type: 'secondary' as const
        };
      });
      
      // Short delay for appreciation, then advance level and start celebration
      setTimeout(() => {
        // NOW advance to next level
        gameLogic.nextLevel();
        const nextState = gameLogic.getState();
        setGameState(nextState);
        
        // Start bubble explosion
        setBubbles([...primaryBubbles, ...secondaryBubbles]);
        setShowSuccessFlash(false);
        
        // Check for heart bonus - EXCITING CELEBRATION!
        if (nextState.hearts > prevHearts) {
          // Enhanced haptic feedback for heart gain
          triggerHaptic('heavy');
          
          // Show heart gain celebration
          setShowHeartGain(true);
          
          // Create heart burst animation
          const heartBubbles = Array.from({ length: 20 }, (_, i) => {
            const angle = (i / 20) * 2 * Math.PI;
            const distance = 200 + Math.random() * 200;
            return {
              id: `heart-${Date.now()}-${i}`,
              x: Math.cos(angle) * distance,
              y: Math.sin(angle) * distance,
              size: 15 + Math.random() * 10,
              color: '#FF1493', // Deep pink for hearts
              type: 'primary' as const,
              delay: Math.random() * 200
            };
          });
          setBubbles(prev => [...prev, ...heartBubbles]);
          
          setTimeout(() => setShowHeartGain(false), 3000);
        }
        
        // Update stats
        updateStats({
          currentLevel: nextState.currentLevel,
          bestLevel: Math.max((stats as any)?.bestLevel || 0, nextState.currentLevel),
          hearts: nextState.hearts,
          totalPlays: ((stats as any)?.totalPlays || 0) + 1,
        });
        
        // Enhanced vibration for bubble explosion
        if ('vibrate' in navigator) {
          // Multiple vibration bursts for bubble explosion effect
          navigator.vibrate([100, 50, 100, 50, 150]);
        }
        
        // Clear bubbles after animation
        setTimeout(() => setBubbles([]), 3000);
      }, 800); // Show matched result for 0.8 seconds



      if (result.bonusHeart) {
        // Show heart animation only, no toast popup
        setShowHeartGain(true);
        setTimeout(() => setShowHeartGain(false), 1000);
      }
    }

    if (result.gameOver) {
      triggerHaptic('heavy');
      const finalLevel = gameState.currentLevel; // The level they reached before running out of hearts
      
      // Store the final level reached for the modal
      setFinalLevelReached(finalLevel);
      
      // Show hearts-out modal instead of game over modal
      setShowHeartsOut(true);
    }
  };

  const handleResetLevel = () => {
    // Reset to level 1 with 3 hearts
    const newLogic = new ColorMergeLogic(1, 3);
    setGameLogic(newLogic);
    setGameState(newLogic.getState());
    setAllIncorrectGuesses([]);
    
    // Update stats to reflect level 1 restart
    updateStats({
      currentLevel: 1,
      hearts: 3,
      bestLevel: (stats as any)?.bestLevel || 0, // Keep best level
      totalPlays: ((stats as any)?.totalPlays || 0) + 1,
    });
  };

  const handleNewGame = () => {
    // Create completely new game logic starting from level 1
    const newLogic = new ColorMergeLogic(1, 3);
    setGameLogic(newLogic);
    setGameState(newLogic.getState());
    setAllIncorrectGuesses([]);
    setShowGameOver(false);
    setShowHeartsOut(false);
    
    // Update stats to reflect level 1 restart
    updateStats({
      currentLevel: 1,
      hearts: 3,
      bestLevel: (stats as any)?.bestLevel || 0, // Keep best level
      totalPlays: ((stats as any)?.totalPlays || 0) + 1,
    });
  };

  const colorButtons = [
    { 
      color: 'blue', 
      exactColor: 'rgb(0, 0, 255)',
      bgColor: 'from-blue-400 to-blue-600', 
      shadowColor: 'shadow-blue-500/50' 
    },
    { 
      color: 'red', 
      exactColor: 'rgb(255, 0, 0)',
      bgColor: 'from-red-400 to-red-600', 
      shadowColor: 'shadow-red-500/50' 
    },
    { 
      color: 'yellow', 
      exactColor: 'rgb(255, 255, 0)',
      bgColor: 'from-yellow-300 to-yellow-500', 
      shadowColor: 'shadow-yellow-500/50' 
    },
    { 
      color: 'white', 
      exactColor: 'rgb(255, 255, 255)',
      bgColor: 'from-gray-100 to-white', 
      shadowColor: 'shadow-gray-500/50', 
      textColor: 'text-gray-800' 
    },
    { 
      color: 'black', 
      exactColor: 'rgb(0, 0, 0)',
      bgColor: 'from-gray-800 to-black', 
      shadowColor: 'shadow-gray-900/50' 
    },
  ];

  // Get dynamic text color based on background
  const targetColor = gameLogic.getTargetColorString();
  const textColorClass = getContrastTextColor(targetColor);

  // Pie chart component for showing color mixtures
  const ColorPieChart = ({ colors, size = 80 }: { colors: string[]; size?: number }) => {
    const colorCounts = colors.reduce((acc, color) => {
      acc[color] = (acc[color] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const total = colors.length;
    let currentAngle = 0;

    const segments = Object.entries(colorCounts).map(([color, count]) => {
      const percentage = count / total;
      const angle = percentage * 360;
      const startAngle = currentAngle;
      const endAngle = currentAngle + angle;
      currentAngle += angle;

      const startX = Math.cos((startAngle - 90) * Math.PI / 180) * (size/2);
      const startY = Math.sin((startAngle - 90) * Math.PI / 180) * (size/2);
      const endX = Math.cos((endAngle - 90) * Math.PI / 180) * (size/2);
      const endY = Math.sin((endAngle - 90) * Math.PI / 180) * (size/2);
      
      const largeArcFlag = angle > 180 ? 1 : 0;
      
      const pathData = [
        `M ${size/2} ${size/2}`,
        `L ${size/2 + startX} ${size/2 + startY}`,
        `A ${size/2} ${size/2} 0 ${largeArcFlag} 1 ${size/2 + endX} ${size/2 + endY}`,
        'Z'
      ].join(' ');

      return { color, count, pathData };
    });

    return (
      <div className="flex flex-col items-center">
        <svg width={size} height={size} className="drop-shadow-lg">
          {segments.map(({ color, count, pathData }, index) => (
            <path
              key={index}
              d={pathData}
              fill={color}
              stroke="white"
              strokeWidth="2"
            />
          ))}
        </svg>
        <div className="mt-2 flex flex-wrap justify-center gap-1">
          {Object.entries(colorCounts).map(([color, count]) => (
            <div key={color} className="flex items-center text-xs bg-black/20 rounded px-2 py-1">
              <div 
                className="w-3 h-3 rounded-full mr-1 border border-white/50" 
                style={{ backgroundColor: color }}
              />
              <span className={textColorClass}>{count}</span>
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <>
      {/* Full Background with Target Color - Quick transition */}
      <div 
        className={`fixed inset-0 transition-all duration-700 ease-in-out ${
          showSuccessFlash ? 'animate-[celebrate-success_400ms_ease-out_forwards]' : ''
        }`}
        style={{ 
          backgroundColor: gameLogic.getTargetColorString()
        }}
      />
      
      {/* Bubble Burst Animation Layer */}
      <div className="fixed inset-0 pointer-events-none z-30">
        {bubbles.map((bubble) => {
          const isPrimary = bubble.type === 'primary';
          const animationName = isPrimary ? 'bubble-swoop' : 'bubble-explode';
          const duration = isPrimary ? '2500ms' : '1800ms';
          
          return (
            <div
              key={bubble.id}
              className={`absolute rounded-full`}
              style={{
                left: '50%',
                top: '50%',
                width: `${bubble.size}px`,
                height: `${bubble.size}px`,
                backgroundColor: bubble.color, // Force the exact matched background color
                border: '1px solid rgba(255,255,255,0.1)',
                '--bubble-x': `${bubble.x}px`,
                '--bubble-y': `${bubble.y}px`,
                marginLeft: `-${bubble.size/2}px`,
                marginTop: `-${bubble.size/2}px`,
                boxShadow: `0 0 8px rgba(0,0,0,0.2), inset 0 1px 2px rgba(255,255,255,0.3)`,
                animation: `${animationName} ${duration} cubic-bezier(0.25, 0.46, 0.45, 0.94) ${bubble.delay}ms forwards`,
                willChange: 'transform, opacity',
              } as React.CSSProperties}
            />
          );
        })}
      </div>
      
      <div className={`h-screen flex flex-col relative z-10 overflow-hidden transition-all duration-300 isolate-layer ${
        showSuccessFlash ? 'ring-8 ring-green-400/50' : showHeartLoss ? 'ring-8 ring-red-500/50' : ''
      }`}>
        {/* Floating Particles with Success Celebration */}
        <div className="absolute inset-0 pointer-events-none z-0">
          {Array.from({ length: 6 }, (_, i) => (
            <div
              key={i}
              className={`absolute w-2 h-2 rounded-full transition-all duration-500 ${
                showSuccessFlash 
                  ? 'bg-yellow-300/80 w-3 h-3 animate-bounce' 
                  : 'bg-transparent'
              }`}
              style={{
                left: `${20 + i * 15}%`,
                top: `${10 + (i % 3) * 30}%`,
                animationDelay: `${i * 0.5}s`,
                animationDuration: showSuccessFlash ? `${0.8 + i * 0.2}s` : `${3 + i * 0.5}s`
              }}
            />
          ))}
        </div>

        {/* Header without Title */}
        <div className="relative p-4 z-20">
          {/* Controls on left and right */}
          <div className="flex items-center justify-between">
            {/* Left side controls */}
            <div className="flex items-center space-x-2">
              <Button
                onClick={() => setSoundEnabled(!soundEnabled)}
                variant="ghost"
                size="sm"
                className={`w-10 h-10 rounded-full bg-opacity-90 hover:bg-black/30 relative z-30 pointer-events-auto transition-all duration-300 ${
                  showSuccessFlash ? 'bg-green-500/80 ring-2 ring-green-400' : 'bg-black/20'
                }`}
              >
                {soundEnabled ? <Volume2 className={`w-5 h-5 transition-colors duration-300 ${showSuccessFlash ? 'text-white' : textColorClass}`} /> : <VolumeX className={`w-5 h-5 transition-colors duration-300 ${showSuccessFlash ? 'text-white' : textColorClass}`} />}
              </Button>
              <Button
                onClick={() => setEnhancedHaptics(!enhancedHaptics)}
                variant="ghost"
                size="sm"
                className={`w-10 h-10 rounded-full bg-opacity-90 hover:bg-black/30 relative z-30 pointer-events-auto transition-all duration-300 ${
                  showSuccessFlash 
                    ? 'bg-green-500/80 ring-2 ring-green-400' 
                    : enhancedHaptics 
                      ? 'bg-yellow-500/30' 
                      : 'bg-black/20'
                }`}
              >
                <Zap className={`w-5 h-5 transition-colors duration-300 ${showSuccessFlash ? 'text-white' : textColorClass}`} />
              </Button>
            </div>

            {/* Right side controls */}
            <div className="flex items-center space-x-2">
              <Button
                onClick={() => setIsPaused(!isPaused)}
                variant="ghost"
                size="sm"
                className={`w-10 h-10 rounded-full bg-opacity-90 hover:bg-black/30 relative z-30 pointer-events-auto transition-all duration-300 ${
                  showSuccessFlash ? 'bg-green-500/80 ring-2 ring-green-400' : 'bg-black/20'
                }`}
              >
                <Pause className={`w-4 h-4 transition-colors duration-300 ${showSuccessFlash ? 'text-white' : textColorClass}`} />
              </Button>
              <Button
                onClick={() => setShowInstructions(true)}
                variant="ghost"
                size="sm"
                className={`w-10 h-10 rounded-full bg-opacity-90 hover:bg-black/30 relative z-30 pointer-events-auto transition-all duration-300 ${
                  showSuccessFlash ? 'bg-green-500/80 ring-2 ring-green-400' : 'bg-black/20'
                }`}
              >
                <HelpCircle className={`w-4 h-4 transition-colors duration-300 ${showSuccessFlash ? 'text-white' : textColorClass}`} />
              </Button>
              <Button
                onClick={handleResetLevel}
                variant="ghost"
                size="sm"
                className={`w-10 h-10 rounded-full bg-opacity-90 hover:bg-black/30 relative z-30 pointer-events-auto transition-all duration-300 ${
                  showSuccessFlash ? 'bg-green-500/80 ring-2 ring-green-400' : 'bg-black/20'
                }`}
              >
                <RotateCcw className={`w-5 h-5 transition-colors duration-300 ${showSuccessFlash ? 'text-white' : textColorClass}`} />
              </Button>
            </div>
          </div>
          
          {/* Stats Row Below Title */}
          <div className="flex items-center justify-center space-x-4 mt-4">
            {/* Best Score */}
            <div className={`flex flex-col items-center bg-opacity-90 rounded-2xl px-3 py-2 border transition-all duration-300 ${
              showSuccessFlash 
                ? 'bg-green-500/80 border-green-400 ring-2 ring-green-400' 
                : 'bg-black/20 border-white/20'
            }`}>
              <Trophy className={`w-4 h-4 mb-1 transition-colors duration-300 ${
                showSuccessFlash ? 'text-white' : 'text-yellow-400'
              }`} />
              <span className={`text-xs opacity-70 transition-colors duration-300 ${
                showSuccessFlash ? 'text-white' : textColorClass
              }`}>Best</span>
              <span className={`text-lg font-bold transition-colors duration-300 ${
                showSuccessFlash ? 'text-white' : textColorClass
              }`}>{(stats as any)?.bestLevel || 0}</span>
            </div>
            
            {/* Current Level */}
            <div className={`flex flex-col items-center bg-opacity-90 rounded-2xl px-3 py-2 border transition-all duration-300 ${
              showSuccessFlash 
                ? 'bg-green-500/80 border-green-400 ring-2 ring-green-400' 
                : 'bg-black/20 border-white/20'
            }`}>
              <div className={`w-4 h-4 rounded-full mb-1 flex items-center justify-center transition-colors duration-300 ${
                showSuccessFlash ? 'bg-white' : 'bg-blue-400'
              }`}>
                <span className={`text-xs font-bold transition-colors duration-300 ${
                  showSuccessFlash ? 'text-green-500' : 'text-white'
                }`}>{gameState.currentLevel}</span>
              </div>
              <span className={`text-xs opacity-70 transition-colors duration-300 ${
                showSuccessFlash ? 'text-white' : textColorClass
              }`}>Level</span>
              <span className={`text-lg font-bold transition-colors duration-300 ${
                showSuccessFlash ? 'text-white' : textColorClass
              }`}>{gameState.currentLevel}</span>
              {gameState.currentLevel % 10 === 0 && gameState.currentLevel > 0 && (
                <div className="absolute -top-1 -right-1 bg-gradient-to-r from-yellow-400 to-orange-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold animate-bounce shadow-lg">
                  💖
                </div>
              )}
            </div>
            
            {/* Hearts */}
            <div className={`flex flex-col items-center bg-opacity-90 rounded-2xl px-3 py-2 border relative transition-all duration-300 ${
              showSuccessFlash 
                ? 'bg-green-500/80 border-green-400 ring-2 ring-green-400' 
                : showHeartGain 
                ? 'bg-gradient-to-r from-yellow-400 to-pink-500 border-yellow-300 ring-2 ring-yellow-400 animate-pulse scale-110'
                : 'bg-black/20 border-white/20'
            }`}>
              <Heart className={`w-4 h-4 fill-current mb-1 transition-colors duration-300 ${
                showSuccessFlash ? 'text-white' : 'text-red-400'
              }`} />
              <span className={`text-xs opacity-70 transition-colors duration-300 ${
                showSuccessFlash ? 'text-white' : textColorClass
              }`}>Hearts</span>
              <span className={`text-lg font-bold transition-colors duration-300 ${
                showSuccessFlash ? 'text-white' : textColorClass
              }`}>{gameState.hearts}</span>
              {showHeartLoss && (
                <div className="absolute top-16 left-1/2 transform -translate-x-1/2 animate-bounce">
                  <span className="text-xl text-black font-bold drop-shadow-lg bg-white/90 rounded-full px-2 py-1">-1</span>
                </div>
              )}
              {showHeartGain && (
                <div className="absolute top-16 left-1/2 transform -translate-x-1/2 animate-bounce z-50">
                  <div className="bg-gradient-to-r from-yellow-400 via-pink-500 to-red-500 text-white rounded-full px-4 py-2 font-bold text-xl shadow-2xl border-2 border-white animate-pulse">
                    ❤️ +1 HEART! ❤️
                  </div>
                  <div className="text-center mt-2 text-sm font-bold text-yellow-300 drop-shadow-lg animate-pulse">
                    AMAZING!
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>



        {/* Main Game Area - Centered Mixing Circle */}
        <div className="flex-1 flex flex-col items-center justify-center relative z-20 pointer-events-auto">
          {/* Current Mix Display - Circle with progressive filling */}
          <div className="text-center mb-8">
            <div className="relative">
              {/* Base circle starts white each round */}
              <div 
                className={`rounded-full bg-white relative overflow-hidden transition-all duration-300 ${
                  showSuccessFlash ? 'w-48 h-48' : 'w-48 h-48 border-4'
                }`}
                style={{
                  borderColor: showSuccessFlash 
                    ? 'transparent'
                    : gameLogic.isTargetWhite()
                      ? 'rgba(0, 0, 0, 0.8)' 
                      : 'rgba(255, 255, 255, 0.6)'
                }}
              >
                {/* Fill progress with mixed color */}
                <div
                  className="absolute transition-all duration-500 ease-out"
                  style={{ 
                    backgroundColor: gameLogic.getCurrentColorString(),
                    height: `${(gameState.mixCount / gameState.maxMixes) * 100 + 20}%`, // Extra height to hide bottom edge
                    width: '110%', // Extra width to hide side edges
                    left: '-5%', // Center the wider element
                    bottom: '-10%', // Start lower to hide bottom edge
                    borderRadius: gameState.mixCount === gameState.maxMixes ? '100%' : '0 0 100% 100%',
                    borderTop: (gameLogic.isCurrentMixWhite() && gameState.mixCount > 0) ? '2px solid rgba(0, 0, 0, 0.4)' : 'none'
                  }}
                />
              </div>
            </div>
          </div>

          {/* Mix Progress Indicator - Real-time color matching */}
          <div className="flex items-center justify-center space-x-3 mb-8 bg-black/30 rounded-2xl p-3 border border-white/20">
            {colorButtons.map(({ color }) => {
              const count = gameState.colorClicks[color] || 0;
              const currentMixColor = gameLogic.getCurrentColorString();
              return (
                <div
                  key={color}
                  className="relative flex items-center justify-center w-10 h-10 rounded-full border-2 border-white/30 transition-all duration-300"
                  style={{ backgroundColor: currentMixColor }}
                >
                  <div
                    className={`w-6 h-6 rounded-full ${color === 'white' ? 'border-2 border-gray-400' : ''}`}
                    style={{ 
                      backgroundColor: colorButtons.find(btn => btn.color === color)?.exactColor || color
                    }}
                  />
                  <div 
                    className="absolute -top-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold border border-white/50"
                    style={{ 
                      backgroundColor: currentMixColor,
                      color: getContrastTextColor(currentMixColor) === 'text-white' ? 'white' : 'black'
                    }}
                  >
                    {count}
                  </div>
                </div>
              );
            })}
            <div className="w-px h-6 bg-white/30 mx-2"></div>
            <div 
              className="flex items-center justify-center w-10 h-10 rounded-full bg-opacity-90 border-2 border-white/30 transition-all duration-300"
              style={{ backgroundColor: gameLogic.getCurrentColorString() }}
            >
              <span 
                className="font-bold text-sm"
                style={{ 
                  color: getContrastTextColor(gameLogic.getCurrentColorString()) === 'text-white' ? 'white' : 'black'
                }}
              >
                {gameLogic.getRemainingMixes()}
              </span>
            </div>
          </div>

          {/* Color Buttons */}
          <div className="flex items-center justify-center space-x-4 mb-4 relative z-20 pointer-events-auto">
            {colorButtons.map(({ color, exactColor, bgColor, shadowColor, textColor = 'text-white' }) => (
              <Button
                key={color}
                onClick={() => handleColorClick(color)}
                disabled={gameLogic.getRemainingMixes() <= 0 || isPaused}
                className={`w-16 h-16 rounded-2xl shadow-lg hover:shadow-xl transform hover:scale-110 active:scale-95 transition-all duration-200 border-2 border-white/40 disabled:opacity-50 disabled:cursor-not-allowed ${textColor} game-interactive touch-enabled`}
                style={{ 
                  backgroundColor: exactColor,
                  zIndex: 50,
                  border: color === 'white' ? '2px solid rgba(0,0,0,0.3)' : '2px solid rgba(255,255,255,0.4)'
                }}
              />
            ))}
          </div>
        </div>

        {/* Pause Overlay */}
        {isPaused && (
          <div className="fixed inset-0 bg-black/50 bg-opacity-90 flex items-center justify-center z-50">
            <div className="bg-white/95 rounded-2xl p-8 shadow-2xl">
              <h2 className="text-2xl font-bold text-center mb-4 text-gray-900">Game Paused</h2>
              <Button
                onClick={() => setIsPaused(false)}
                className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
              >
                Resume Game
              </Button>
            </div>
          </div>
        )}
      </div>

      <InstructionsModal
        open={showInstructions}
        onOpenChange={setShowInstructions}
        game="colormerge"
      />

      <GameOverModal
        open={showGameOver}
        onOpenChange={setShowGameOver}
        finalLevel={finalLevelReached}
        bestLevel={(stats as any)?.bestLevel || 0}
        incorrectGuesses={allIncorrectGuesses}
        onPlayAgain={handleNewGame}
      />

      <HeartsOutModal
        open={showHeartsOut}
        onOpenChange={setShowHeartsOut}
        finalLevel={finalLevelReached}
        bestLevel={(stats as any)?.bestLevel || 0}
        incorrectGuesses={allIncorrectGuesses}
        onRestart={handleNewGame}
      />

    </>
  );
}
